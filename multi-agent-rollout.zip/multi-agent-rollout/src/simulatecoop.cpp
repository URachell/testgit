#include "simulate.hpp"
#include "environment.hpp"
#include "boxpicker.hpp"
#include "controlpicker.hpp"
#include "updatetargets.hpp"
#include <random>
#include <math.h>   
#include "coopalgorithm.hpp"
#include<thread>

bool simulateCoop(int numOfAgents, bool displayEnvironment, int msSleepDuration){
    int wallOffset = 10;
    int requestPointOffset = 5;
    int obstacleCount=20;
    int requestCount=16;
    //int n = (int)ceil(sqrt((double)numOfAgents) / 2.0);

    Environment env(numOfAgents,obstacleCount,requestCount);

    int height = ENV_HEIGHT;
    int width = ENV_WIDTH;
    std::array<int, ENV_CAPACITY>& matrix = env.getMatrixArray();

    std::unordered_map<int, int> posToTargetIdx;

    std::vector<std::pair<int, int>> requestPoints;
    for(size_t i = 0; i < height * width; ++i){
        if(matrix[i] == 3){
            requestPoints.push_back(indexToPair(i, ENV_WIDTH));
            posToTargetIdx[i] = requestPoints.size() - 1;
        }
    }
    std::vector< std::pair<int, int> > targets;
    boxPicker(env, targets, -1); // Initialize targets
    std::vector<std::pair<int, int>> startingPositions;
    startingPositions=env.getStartingPositions();
    double cost = 0.0;

    // Calculate controls    
    std::vector<Node> obstacles;
    std::vector<Node> initial_positions;
	std::vector<Node> target_positions;

    for(int i = 0; i < height; i++){
        for(int j = 0; j < width; j++){
            int el = env.envMat(i, j);
            if(el == 1 || el == 2){
                obstacles.push_back(Node(i, j));
            }
            else if(abs(el) >= 4){
                initial_positions.push_back(Node(i, j));
            }
        }
    }

    init_reservation_table(height, width, obstacles);

    std::vector<std::vector<int>> controlsVec(numOfAgents, std::vector<int>());

    int iteration = 0;
    while(!env.isDone()){
        target_positions.clear();
        for(auto el : targets)
            target_positions.push_back(Node(el.first, el.second));
        std::vector<Node> positions;
        for(int agent_idx = 0; agent_idx < numOfAgents; agent_idx++){

            if(controlsVec[agent_idx].size() == 0){
                std::pair<int,int> position = indexToPair(env.getMatrixIndex(agent_idx), width);

                Node node_pos(position.first, position.second);
                remove_from_obstacles(node_pos); 
                controlsVec[agent_idx] = compute_controls_for_single_agent(node_pos, target_positions, iteration, agent_idx);

				if (controlsVec[agent_idx].size() == 0) {
					return false;
				}
            }
        }

        auto beforeValues = env.getAgentValues();

        Environment beforeEnv = env;
        std::vector<int> controls;
        for(int i = 0; i < numOfAgents; i++){
            int N = controlsVec[i].size();
            controls.push_back(controlsVec[i][N - 1]);
        }

        cost = env.step(controls, targets); 

        updateTargets(env, targets, beforeValues, startingPositions);

        iteration++;
        

        for(int agent_idx = 0; agent_idx < numOfAgents; agent_idx++){
            controlsVec[agent_idx].pop_back();
        }
        if (displayEnvironment) {
            env.printMatrix(true);
        }
        if (msSleepDuration != 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(msSleepDuration));
        }
    }

    return true;
}
