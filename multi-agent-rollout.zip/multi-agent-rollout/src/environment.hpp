#pragma once
#include <vector>
#include <cstdint>
#include "assert.h"
#include <algorithm>
#include <array>
#include <chrono>

#define ENV_HEIGHT 17
#define ENV_WIDTH 35
#define ENV_CAPACITY (ENV_HEIGHT * ENV_WIDTH)

class Environment{ 
    private:
        int m_stepCount;
        int m_requestsLeft;
        std::array<int, ENV_CAPACITY> m_matrix;
        std::vector<std::pair<int, int>> m_agentPositions; 
        std::vector<std::pair<int, int>> m_startingPositions; 
        std::vector<std::pair<int, int>> m_availableRequests;


    public:
        Environment(int agentCount,int obstacleCount,int requestCount);
        std::chrono::duration<double>executionTime;
        
        std::pair<int,int> generateRandomPosition(int minX,int maxX,int minY,int maxY,
                                std::vector<std::pair<int,int>>&occupied);
        int &envMat(int n, int m);
        void generateRequestPoints(int requestCount);
        void generateObstacles(int obstacleCount);
        void printMatrix(bool redraw);
        int getNumOfAgents();
        std::array<int, ENV_CAPACITY>& getMatrixArray();
        bool isDone();
        int getStepCount();
        int getRequestsLeft();
        const std::vector<std::pair<int,int>>& getStartingPositions() const;
        int getMatrixIndex(int agentIdx); 
        std::vector<int> getAgentValues();
        std::vector<std::pair<int,int>> &getAvailableRequests();

        // Returns the cost of a given set of actions as well as updates the environment
        double step(std::vector<int> &actions, std::vector< std::pair<int, int> > &targets); 


		void forceFinish();
};
