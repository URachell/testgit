#include "basepolicy.hpp"
#include "indextopair.hpp"
#include "initastar.hpp"
#include "astar.hpp"
#include "string.h"
void reservePath(char* paths, const std::vector<float>&obstacles, int height, int width, int startIdx, int goalIdx, int numOfTargets, int targetIdx){
    std::vector<int> path(height*width,-1);
    bool foundPath=astar(obstacles.data(),height,width,startIdx,goalIdx,false,path.data());
    if(!foundPath){
        //delete[]path;
        return;
    }

    int index = goalIdx;
    
    while(index != startIdx){
        int prevIndex = path[index];
        
        // Calculate control
        auto curr = indexToPair(index, width);
        auto prev = indexToPair(prevIndex, width);

        int di = curr.first - prev.first;
        int dj = curr.second - prev.second;
        //if (prev.first < 0 || prev.first >= height || prev.second < 0 || prev.second >= width || targetIdx < 0 || targetIdx >= numOfTargets) {
        //std::cerr << "Invalid indices: prev: (" << prev.first << ", " << prev.second << "), targetIdx: " << targetIdx << std::endl;
        //return; // 或者适当的错误处理
//}

        int control=(di > 0)? 2 :(di < 0)? 1 :(dj > 0)? 4 : 3;
        paths[prev.second + width * prev.first + height * width * targetIdx] = control;
        index = prevIndex;
        //std::cout << "prev: (" << prev.first << ", " << prev.second << "), ";
        //std::cout << "width: " << width << ", height: " << height << ", targetIdx: " << targetIdx << ", ";
        //std::cout << "Index: " << index << ", Paths size: " << height*width*numOfTargets<<std::endl;

    }

    //delete[] path; // Consider overriding instead of deleting every time
}

void initAstar(char* paths, Environment &env, std::vector<std::pair<int, int>> requests, std::vector<std::pair<int, int>> startingPositions){
    int height = ENV_HEIGHT;
    int width = ENV_WIDTH;
    std::array<int,ENV_CAPACITY>& matrix = env.getMatrixArray();

    std::vector<float>obstacles(height*width,1.0f); // initialize path with 1

    for(size_t i = 0; i < height * width; ++i){
        if(matrix[i] == 1 || matrix[i] == 2)
            obstacles[i] = std::numeric_limits<float>::max();
            
    }
    

    int numOfTargets = requests.size() + startingPositions.size();
    // Initial positions to requestPoints
    for(int i = 0; i < requests.size(); i++){
         auto request = requests[i];
         int goalIdx = width * request.first + request.second;
         obstacles[goalIdx] = 1.0f;

        // for(int agentIdx = 0; agentIdx < env.getNumOfAgents(); agentIdx++){
        //     int startIdx = env.getMatrixIndex(agentIdx);
        //     th(paths, obstacles, height, width, startIdx, goalIdx, numOfTargets, i);
        // }
#pragma omp parallel for
        for(int agentIdx = 0; agentIdx < env.getNumOfAgents(); agentIdx++){
            //auto start = startingPositions[startIdx];
            int startIdx = env.getMatrixIndex(agentIdx);
            reservePath(paths, obstacles, height, width, startIdx, goalIdx, numOfTargets, i);
            reservePath(paths, obstacles, height, width, goalIdx, startIdx, numOfTargets, requests.size() + agentIdx);
        }

        obstacles[goalIdx] = std::numeric_limits<float>::max();
    }

    //obstacles[goalIdx]=std::numeric_limits<float>::max();
}