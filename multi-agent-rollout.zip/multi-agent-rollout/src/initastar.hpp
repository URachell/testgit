#pragma once
#include "environment.hpp"
#include <vector>

void reservePath(char* paths, const std::vector<float>&obstacles, int height, int width, int startIdx, int goalIdx, int numOfTargets, int targetIdx);
void initAstar(char* paths, Environment &env, std::vector<std::pair<int, int>> boxes, std::vector<std::pair<int, int>> dropOffPoints);