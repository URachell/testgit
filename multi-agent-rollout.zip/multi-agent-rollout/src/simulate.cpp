#include "simulate.hpp"
#include "environment.hpp"
#include "boxpicker.hpp"
#include "controlpicker.hpp"
#include "updatetargets.hpp"
#include "initastar.hpp"
#include <random>
#include <math.h>   
#include <unordered_map>
#include <thread>

#define MAX_NUMBER_OF_SHUFFLES 10000
#define RESHUFFLING_THRESHOLD 1000.0

bool simulate(int numOfAgents, bool displayEnvironment, int msSleepDuration){ 
    int wallOffset = 10;
    int requestPointOffset = 10;
    int obstacleCount=4;
    int requestCount=32;
    //int n = (int)ceil(sqrt((double)numOfAgents) / 2.0);

    Environment env(numOfAgents,obstacleCount,requestCount);

    int height = ENV_HEIGHT;
    int width = ENV_WIDTH;
    std::array<int, ENV_CAPACITY>& matrix = env.getMatrixArray();

    std::unordered_map<int, int> posToTargetIdx;

    std::vector<std::pair<int, int>> requestPoints;
    for(size_t i = 0; i < height * width; ++i){
        if(matrix[i] == 3){
            requestPoints.push_back(indexToPair(i, ENV_WIDTH));
            posToTargetIdx[i] = requestPoints.size() - 1;
        }
    }
    std::vector< std::pair<int, int> > targets;
    boxPicker(env, targets, -1); // Initialize targets

    std::vector<std::pair<int, int>> startingPositions;
    startingPositions=env.getStartingPositions();
    for(int i = 0; i < startingPositions.size(); ++i){
        auto startPos = startingPositions[i];
        posToTargetIdx[startPos.second + startPos.first * width] = requestPoints.size() + i;
    }

    int pathsSize = 2*ENV_WIDTH * ENV_HEIGHT * env.getRequestsLeft()*startingPositions.size();
    char* paths = new char[pathsSize];
    for(int i = 0; i < pathsSize; i++)
        paths[i] = -1;
    //std::cout<<env.getRequestsLeft()<<std::endl;
    //std::vector<std::pair<int,int>>
    initAstar(paths, env, requestPoints, startingPositions);

    double cost = 0.0;
    auto rd = std::random_device {}; 
    auto rng = std::default_random_engine {rd()};

    // Initialize agent order
    std::vector<int> agentOrder(numOfAgents);
    for(size_t i = 0; i < numOfAgents; ++i)
        agentOrder[i] = i;

    int iteration = 0;
    while(!env.isDone()){
        
        auto controls = controlPicker(env, targets, startingPositions, agentOrder, false, paths, posToTargetIdx);

        auto beforeValues = env.getAgentValues();

        Environment beforeEnv = env;

        cost = env.step(controls, targets); 

        if(cost > RESHUFFLING_THRESHOLD){
            double shuffleCost = std::numeric_limits<float>::max();
            std::vector<int> shuffledAgentOrder = agentOrder;

            Environment shuffleEnv = beforeEnv;
            std::vector<int> shuffleControls;

            int shuffleCount = 0;

            auto prevControls = std::vector<int>();

            while(shuffleCost > RESHUFFLING_THRESHOLD){
                shuffleEnv = beforeEnv;

                std::shuffle(std::begin(shuffledAgentOrder), std::end(shuffledAgentOrder), rng);
                shuffleControls = controlPicker(shuffleEnv, targets, startingPositions, shuffledAgentOrder, true, paths, posToTargetIdx);

                shuffleCost = shuffleEnv.step(shuffleControls, targets); 
                shuffleCount++; 

                if(shuffleCount > MAX_NUMBER_OF_SHUFFLES){
                    if (displayEnvironment) {
                        beforeEnv.printMatrix(false);
                    }
                    return false;
                }

                prevControls = shuffleControls;
            }

            env = shuffleEnv;
            cost = shuffleCost;
            controls = shuffleControls;
            agentOrder = shuffledAgentOrder;

            iteration++;

        }

        updateTargets(env, targets, beforeValues, startingPositions);

        if (displayEnvironment) {
            
            env.printMatrix(true);
        }
        std::cout << "Iteration: " << iteration << ", Cost: " << cost << std::endl;
        if (msSleepDuration != 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(msSleepDuration));
        }
    }

    delete[] paths;
    return true;
}
