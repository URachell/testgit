#include "environment.hpp"
#include <iostream>
#include <ctime>
#include <queue>
#include <cmath>
#include <algorithm>
#include <random>
// Objects in matrix
enum object {space, wall, obstacle,request, firstAgent};

// Costs
static const double c_step = 1.0, c_answered = -10000.0, c_returnToStart = -10000.0, c_collision = 1e20;
const int NUM_AGENTS=8;
const int NUM_TASKS=10;
const int NUM_OBSTACLES=4;
static constexpr double discountFactor = 0.999;

template<int N>
struct Discount {
    double arr[N];
    constexpr Discount () : arr() {
        arr[0] = 1.0;
        for (int i = 1; i <  N; ++i)
            arr[i] = arr[i - 1] * discountFactor;
    }
};
static constexpr auto discountFactors = Discount<10000>();
struct Position
{
    int x,y;
};
struct Task
{
    Position position;
    bool assigned=false;
};
std::pair<int,int> Environment::generateRandomPosition(int minX,int maxX,int minY,int maxY,
                                std::vector<std::pair<int,int>>&occupied){

        std::default_random_engine gen(std::random_device{}());
        std::uniform_int_distribution<int> disX(minX, maxX);
        std::uniform_int_distribution<int> disY(minY, maxY);
        std::pair<int,int> pos;
        do {
            pos.first = disX(gen);
            pos.second = disY(gen);
        } while (std::find_if(occupied.begin(), occupied.end(), [&](const std::pair<int,int>& p){
            return p.first == pos.first && p.second == pos.second; 
        })!=occupied.end());
        return pos;
    }


Environment::Environment(int agentCount, int obstacleCount,int requestCount) : m_stepCount(0) {
    m_matrix = {0};
    m_requestsLeft = 0;

    // Populate matrix with walls 
    for(int i = 0; i < ENV_HEIGHT; ++i){
    
        for(int j = 0; j < ENV_WIDTH; ++j){
            envMat(i, j) = (i==0||i==ENV_HEIGHT-1||j==0||j==ENV_WIDTH-1)?wall:space;
        }

    }
    int placedAgent=0;
    for(int i=0;i<agentCount/2;){
        m_agentPositions.push_back(std::make_pair(7,16-i));
        m_startingPositions.push_back(std::make_pair(7,16-i));
        envMat(7,16-i)=-firstAgent -placedAgent;
        placedAgent++;
        //std::cout<<(16-i)*ENV_WIDTH+7;
        m_agentPositions.push_back(std::make_pair(7,18+i));
        m_startingPositions.push_back(std::make_pair(7,18+i));
        envMat(7,18+i)=-firstAgent -placedAgent;
        placedAgent++;
        //std::cout<<(18-i)*ENV_WIDTH+7;
        m_agentPositions.push_back(std::make_pair(9,16-i));
        m_startingPositions.push_back(std::make_pair(9,16-i));
        envMat(9,16-i)=-firstAgent -placedAgent;
        placedAgent++;
        m_agentPositions.push_back(std::make_pair(9,18+i));
        m_startingPositions.push_back(std::make_pair(9,18+i));
        envMat(9,18+i)=-firstAgent -placedAgent;
        placedAgent++;
        //std::cout<<(18-i)*ENV_WIDTH+9;

        i+=2;

    }
    
    generateRequestPoints(requestCount);
    // Populate matrix with obstacles
    generateObstacles(obstacleCount);
    m_requestsLeft=m_availableRequests.size();
    
    
}
void Environment::generateRequestPoints(int requestCount){

    std::vector<std::pair<int,int>> occupiedPositions=m_agentPositions;  
    for(int i=0;i<requestCount;++i){
        std::pair<int,int>obs=generateRandomPosition(2,ENV_HEIGHT-3,2,ENV_WIDTH-3,
        occupiedPositions);
        envMat(obs.first, obs.second) = request;
        occupiedPositions.push_back(obs);
        m_availableRequests.push_back(obs);
    }
}
void Environment::generateObstacles(int obstacleCount){
    std::vector<std::pair<int,int>> occupiedPositions=m_availableRequests;
    for(int i=0;i<m_startingPositions.size();++i){
        occupiedPositions.push_back(m_startingPositions[i]);
    }  
    for(int i=0;i<obstacleCount;++i){
        std::pair<int,int>obs=generateRandomPosition(1,ENV_HEIGHT-2,1,ENV_WIDTH-2,
        occupiedPositions);
        envMat(obs.first, obs.second) = obstacle;
        occupiedPositions.push_back(obs);
    }
}
int &Environment::envMat(int n, int m){
    return m_matrix[m + n * ENV_WIDTH];
}
//other ways
void Environment::printMatrix(bool redraw){
    if(redraw)
        std::cout << "\033[2J\033[H";
    for(int i = 0; i < ENV_HEIGHT; i++){
        for(int j = 0; j < ENV_WIDTH; j++){
            std::cout << "  ";
            int el = envMat(i, j);
            switch(el){
                case space:
                    std::cout << "  ";
                    break;
                case wall:
                    std::cout << "\033[1;39;44m" << "  " << "\033[0m";
                    break;
                case obstacle:
                    std::cout << "\033[1;31;41m" << "  " << "\033[0m";
                    break;
                case request:
                    std::cout << "\033[1;33;43m" << "  " << "\033[0m";
                    break;
                default:
                    if(el < 0){
                        if(el<-12)
                        std::cout << "\033[0;39;100m" << -el - 3<<"\033[0m";
                        else
                        std::cout << "\033[0;39;100m" << -el - 3<<" \033[0m";
                    }else{
                        if(el>12)
                       std::cout << "\033[0;39;42m " << el - 3 << "\033[0m";
                       else
                       std::cout << "\033[0;39;42m" << el - 3 << " \033[0m";
                    }
                    
                    break;
            }
        }
        std::cout << "\n\n";
    }
}
//
int Environment::getNumOfAgents(){
    return m_agentPositions.size();
}

std::array<int, ENV_CAPACITY>& Environment::getMatrixArray(){
    return m_matrix;
}

bool Environment::isDone(){
    return m_requestsLeft == 0 ? true : false;
}


int Environment::getMatrixIndex(int agentIdx){
    auto pos = m_agentPositions[agentIdx];
    return ENV_WIDTH * pos.first + pos.second;
}

std::vector<int> Environment::getAgentValues(){
    std::vector<int> output(m_agentPositions.size());

    for(size_t i = 0; i < m_agentPositions.size(); ++i)
        output[i] = m_matrix[ENV_WIDTH * m_agentPositions[i].first + m_agentPositions[i].second];

    return output;
}


std::vector<std::pair<int,int>> &Environment::getAvailableRequests(){
    return m_availableRequests;
}

const std::vector<std::pair<int,int>> &Environment::getStartingPositions() const{
    return m_startingPositions;
}
int Environment::getStepCount(){
    return m_stepCount;
}

int Environment::getRequestsLeft(){
    return m_requestsLeft;
}

// Returns the cost of a given set of controls as well as updates the environment
double Environment::step(std::vector<int> &controls, std::vector<std::pair<int, int>> &targets){
    auto start = std::chrono::high_resolution_clock::now();
    std::vector< std::pair<int, int> > newPositions(m_agentPositions.size());

    double cost = 0;
    const int tot_dim = ENV_HEIGHT * ENV_WIDTH;
    int coll_mat[tot_dim];
    for(int i = 0; i < tot_dim; ++i)
        coll_mat[i] = 0;

    // Find new positions 
    for(size_t agent_index = 0; agent_index < m_agentPositions.size(); ++agent_index){
        std::pair<int,int> agentPos = m_agentPositions[agent_index];
        std::pair<int,int> target = targets[agent_index];
        uint8_t control = controls[agent_index];

        std::pair<int, int> newPos(agentPos.first, agentPos.second); // Stand still

        switch(control){
            case 1: // Move up
                newPos.first = agentPos.first - 1;
                break;
            case 2: // Move down
                newPos.first = agentPos.first + 1;
                break;
            case 3: // Move left
                newPos.second = agentPos.second - 1;
                break;
            case 4: // Move right
                newPos.second = agentPos.second + 1;
                break;
        }
        int newPosEl = envMat(newPos.first, newPos.second);

        // If the new position is a wall or an undesired box, stand still, otherwise move
        if(newPosEl == wall ||newPosEl == obstacle|| (newPosEl == request && newPos != targets[agent_index])){
            newPositions[agent_index] = m_agentPositions[agent_index];
        }
        else{
            newPositions[agent_index] = newPos;
        }
        // Check for and penalize collisions
        if(coll_mat[ENV_WIDTH * newPositions[agent_index].first + newPositions[agent_index].second] != 0){
            cost += c_collision * discountFactors.arr[m_stepCount];
        }else{
            coll_mat[ENV_WIDTH * newPositions[agent_index].first + newPositions[agent_index].second] = 1;
        }
    }


    int swapPenalized[m_agentPositions.size()];
    for(int i = 0; i < m_agentPositions.size(); ++i)
        swapPenalized[i] = 0;
    // Check for and penalize swaps 
    for(size_t i = 0; i < m_agentPositions.size(); ++i){
        // Cannot swap if standing still
        if(newPositions[i] == m_agentPositions[i] || swapPenalized[i] != 0) 
            continue;

        int agent_index = envMat(newPositions[i].first, newPositions[i].second); // Which agent stood here before?
        agent_index = (agent_index>=0) ? agent_index : -agent_index; 

        // Neglect non-agents 
        if(agent_index < firstAgent)
            continue;

        // Is the agent that stood here before, now at my previous position?
        if(newPositions[agent_index - firstAgent] == m_agentPositions[i]){ 
            cost += c_collision * discountFactors.arr[m_stepCount];
            swapPenalized[agent_index - firstAgent] = 1;
        }
    }

    std::vector<int> oldEl(m_agentPositions.size());
    for(size_t agent_index = 0; agent_index < m_agentPositions.size(); ++agent_index){
        oldEl[agent_index] = envMat(m_agentPositions[agent_index].first, m_agentPositions[agent_index].second);
        envMat(m_agentPositions[agent_index].first, m_agentPositions[agent_index].second) = space;
    }
    for(size_t agent_index = 0; agent_index < m_agentPositions.size(); ++agent_index){
        
        if(controls[agent_index] != 0){
            cost += c_step;
            // Update matrix
            envMat(newPositions[agent_index].first, newPositions[agent_index].second) = oldEl[agent_index];}
        else
            envMat(m_agentPositions[agent_index].first, m_agentPositions[agent_index].second)=oldEl[agent_index];

        // If an agent reaches its target
        if(newPositions[agent_index] == targets[agent_index] && m_agentPositions[agent_index] != newPositions[agent_index]){
            if(targets[agent_index].first != 1 && targets[agent_index].first != ENV_HEIGHT - 2){
                if(envMat(newPositions[agent_index].first, newPositions[agent_index].second) < 0){ // If the agent has reached the request point
                    cost += c_answered * discountFactors.arr[m_stepCount];
                    
                }else{
                    cost += c_returnToStart * discountFactors.arr[m_stepCount];
                    m_requestsLeft--;
                    //m_availableRequests[agent_index].erase;
                    //once the agent returns to its starting position it can last be considered as the conpletion of the task
                }
                envMat(newPositions[agent_index].first, newPositions[agent_index].second) = -envMat(newPositions[agent_index].first, newPositions[agent_index].second);
            }
            // else{ // Return to starting position
            //     cost += c_returnToStart * discountFactors.arr[m_stepCount];
            // }
        }

    }
    m_agentPositions = newPositions;
    m_stepCount += 1;
    auto end = std::chrono::high_resolution_clock::now();
    executionTime = end - start;
    //std::cout<<"Execution Time:"<<executionTime.count()<<"seconds."<<std::endl;
    return cost;
    
}

void Environment::forceFinish() {
	m_requestsLeft = 0;
}
