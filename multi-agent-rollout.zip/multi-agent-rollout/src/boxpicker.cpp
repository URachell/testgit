#include "boxpicker.hpp"
#include <random>

void boxPicker(Environment &env, std::vector< std::pair<int,int> > &targets, int agentIdx){
    int height = ENV_HEIGHT;
    int width = ENV_WIDTH;
    std::array<int, ENV_CAPACITY>& matrix = env.getMatrixArray();

    std::vector<std::pair<int,int>> &availableRequests = env.getAvailableRequests();
    //std::cout<<targets.empty()<<std::endl;
    if(targets.empty()){ // Initialization of targets
        // Shuffle the targets

        
        auto rd = std::random_device {}; 
        auto rng = std::default_random_engine {rd()};
        std::shuffle(availableRequests.begin(), availableRequests.end(), rng);
        std::vector<std::pair<int,int>> requests = availableRequests;
        for(size_t i = 0; i < env.getNumOfAgents(); i++){
            auto requestPos = requests[i];
            targets.push_back(requests[i]);
            std::cout<<"("<<requests[i].first<<","<<requests[i].second<<")"<<std::endl;
        }
    }
    else{ // Find the first available request point that is not the target of an other agent
        std::vector<std::pair<int,int>> unassignedRequests;
        for(const auto&request:availableRequests)
        {
            if(std::find(targets.begin(),targets.end(),request)==targets.end()){
                unassignedRequests.push_back(request);
            }
        }
        if(availableRequests.empty()){ // No requests left to answer
			env.forceFinish();
        }else{
            auto requestPos = availableRequests[rand() % unassignedRequests.size()];
            targets[agentIdx] = requestPos;
            
        }
    }
}
